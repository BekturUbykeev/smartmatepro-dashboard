function Container() {
  return (
    <div className="absolute h-[19.5px] left-[166.15px] top-0 w-[5.961px]" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[19.5px] left-0 not-italic text-[13px] text-gray-700 text-nowrap top-px tracking-[-0.0762px] whitespace-pre">1</p>
    </div>
  );
}

function Container1() {
  return (
    <div className="absolute h-[19.5px] left-[202.82px] top-0 w-[7.773px]" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[19.5px] left-0 not-italic text-[13px] text-gray-700 text-nowrap top-px tracking-[-0.0762px] whitespace-pre">2</p>
    </div>
  );
}

function Container2() {
  return (
    <div className="absolute h-[19.5px] left-[240.25px] top-0 w-[8.078px]" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[19.5px] left-0 not-italic text-[13px] text-gray-700 text-nowrap top-px tracking-[-0.0762px] whitespace-pre">3</p>
    </div>
  );
}

function Container3() {
  return (
    <div className="absolute h-[19.5px] left-[277.73px] top-0 w-[8.297px]" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[19.5px] left-0 not-italic text-[13px] text-gray-700 text-nowrap top-px tracking-[-0.0762px] whitespace-pre">4</p>
    </div>
  );
}

function Container4() {
  return (
    <div className="absolute h-[19.5px] left-[315.47px] top-0 w-[7.961px]" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[19.5px] left-0 not-italic text-[13px] text-gray-700 text-nowrap top-px tracking-[-0.0762px] whitespace-pre">5</p>
    </div>
  );
}

function Container5() {
  return (
    <div className="absolute h-[20px] left-0 top-0 w-[451px]" data-name="Container">
      <Container />
      <Container1 />
      <Container2 />
      <Container3 />
      <Container4 />
    </div>
  );
}

function Container6() {
  return <div className="absolute bg-gray-400 h-[10px] left-0 opacity-0 top-0 w-px" data-name="Container" />;
}

function Container7() {
  return <div className="absolute bg-gray-400 h-[10px] left-[18.79px] top-0 w-px" data-name="Container" />;
}

function Container8() {
  return <div className="absolute bg-gray-400 h-[10px] left-[37.58px] top-0 w-px" data-name="Container" />;
}

function Container9() {
  return <div className="absolute bg-gray-400 h-[10px] left-[56.38px] top-0 w-px" data-name="Container" />;
}

function Container10() {
  return <div className="absolute bg-gray-400 h-[10px] left-[75.16px] top-0 w-px" data-name="Container" />;
}

function Container11() {
  return <div className="absolute bg-gray-400 h-[10px] left-[93.95px] top-0 w-px" data-name="Container" />;
}

function Container12() {
  return <div className="absolute bg-gray-400 h-[10px] left-[112.75px] top-0 w-px" data-name="Container" />;
}

function Container13() {
  return <div className="absolute bg-gray-400 h-[10px] left-[131.54px] top-0 w-px" data-name="Container" />;
}

function Container14() {
  return <div className="absolute bg-gray-400 h-[10px] left-[150.33px] top-0 w-px" data-name="Container" />;
}

function Container15() {
  return <div className="absolute bg-gray-400 h-[10px] left-[169.13px] top-0 w-px" data-name="Container" />;
}

function Container16() {
  return <div className="absolute bg-gray-400 h-[10px] left-[187.91px] top-0 w-px" data-name="Container" />;
}

function Container17() {
  return <div className="absolute bg-gray-400 h-[10px] left-[206.7px] top-0 w-px" data-name="Container" />;
}

function Container18() {
  return <div className="absolute bg-gray-400 h-[10px] left-[225.5px] top-0 w-px" data-name="Container" />;
}

function Container19() {
  return <div className="absolute bg-gray-400 h-[10px] left-[244.29px] top-0 w-px" data-name="Container" />;
}

function Container20() {
  return <div className="absolute bg-gray-400 h-[10px] left-[263.08px] top-0 w-px" data-name="Container" />;
}

function Container21() {
  return <div className="absolute bg-gray-400 h-[10px] left-[281.88px] top-0 w-px" data-name="Container" />;
}

function Container22() {
  return <div className="absolute bg-gray-400 h-[10px] left-[300.66px] top-0 w-px" data-name="Container" />;
}

function Container23() {
  return <div className="absolute bg-gray-400 h-[10px] left-[319.45px] top-0 w-px" data-name="Container" />;
}

function Container24() {
  return <div className="absolute bg-gray-400 h-[10px] left-[338.25px] top-0 w-px" data-name="Container" />;
}

function Container25() {
  return <div className="absolute bg-gray-400 h-[10px] left-[357.04px] top-0 w-px" data-name="Container" />;
}

function Container26() {
  return <div className="absolute bg-gray-400 h-[10px] left-[375.83px] top-0 w-px" data-name="Container" />;
}

function Container27() {
  return <div className="absolute bg-gray-400 h-[10px] left-[394.63px] top-0 w-px" data-name="Container" />;
}

function Container28() {
  return <div className="absolute bg-gray-400 h-[10px] left-[413.41px] top-0 w-px" data-name="Container" />;
}

function Container29() {
  return <div className="absolute bg-gray-400 h-[10px] left-[432.2px] top-0 w-px" data-name="Container" />;
}

function Container30() {
  return <div className="absolute bg-gray-400 h-[10px] left-[451px] opacity-0 top-0 w-px" data-name="Container" />;
}

function Container31() {
  return <div className="absolute bg-gray-300 h-[6px] left-[9.39px] opacity-60 top-0 w-px" data-name="Container" />;
}

function Container32() {
  return <div className="absolute bg-gray-300 h-[6px] left-[28.19px] opacity-60 top-0 w-px" data-name="Container" />;
}

function Container33() {
  return <div className="absolute bg-gray-300 h-[6px] left-[46.98px] opacity-60 top-0 w-px" data-name="Container" />;
}

function Container34() {
  return <div className="absolute bg-gray-300 h-[6px] left-[65.77px] opacity-60 top-0 w-px" data-name="Container" />;
}

function Container35() {
  return <div className="absolute bg-gray-300 h-[6px] left-[84.56px] opacity-60 top-0 w-px" data-name="Container" />;
}

function Container36() {
  return <div className="absolute bg-gray-300 h-[6px] left-[103.35px] opacity-60 top-0 w-px" data-name="Container" />;
}

function Container37() {
  return <div className="absolute bg-gray-300 h-[6px] left-[122.14px] opacity-60 top-0 w-px" data-name="Container" />;
}

function Container38() {
  return <div className="absolute bg-gray-300 h-[6px] left-[140.94px] opacity-60 top-0 w-px" data-name="Container" />;
}

function Container39() {
  return <div className="absolute bg-gray-300 h-[6px] left-[159.73px] opacity-60 top-0 w-px" data-name="Container" />;
}

function Container40() {
  return <div className="absolute bg-gray-300 h-[6px] left-[178.52px] opacity-60 top-0 w-px" data-name="Container" />;
}

function Container41() {
  return <div className="absolute bg-gray-300 h-[6px] left-[197.31px] opacity-60 top-0 w-px" data-name="Container" />;
}

function Container42() {
  return <div className="absolute bg-gray-300 h-[6px] left-[216.1px] opacity-60 top-0 w-px" data-name="Container" />;
}

function Container43() {
  return <div className="absolute bg-gray-300 h-[6px] left-[234.89px] opacity-60 top-0 w-px" data-name="Container" />;
}

function Container44() {
  return <div className="absolute bg-gray-300 h-[6px] left-[253.69px] opacity-60 top-0 w-px" data-name="Container" />;
}

function Container45() {
  return <div className="absolute bg-gray-300 h-[6px] left-[272.48px] opacity-60 top-0 w-px" data-name="Container" />;
}

function Container46() {
  return <div className="absolute bg-gray-300 h-[6px] left-[291.27px] opacity-60 top-0 w-px" data-name="Container" />;
}

function Container47() {
  return <div className="absolute bg-gray-300 h-[6px] left-[310.06px] opacity-60 top-0 w-px" data-name="Container" />;
}

function Container48() {
  return <div className="absolute bg-gray-300 h-[6px] left-[328.85px] opacity-60 top-0 w-px" data-name="Container" />;
}

function Container49() {
  return <div className="absolute bg-gray-300 h-[6px] left-[347.64px] opacity-60 top-0 w-px" data-name="Container" />;
}

function Container50() {
  return <div className="absolute bg-gray-300 h-[6px] left-[366.44px] opacity-60 top-0 w-px" data-name="Container" />;
}

function Container51() {
  return <div className="absolute bg-gray-300 h-[6px] left-[385.23px] opacity-60 top-0 w-px" data-name="Container" />;
}

function Container52() {
  return <div className="absolute bg-gray-300 h-[6px] left-[404.02px] opacity-60 top-0 w-px" data-name="Container" />;
}

function Container53() {
  return <div className="absolute bg-gray-300 h-[6px] left-[422.81px] opacity-60 top-0 w-px" data-name="Container" />;
}

function Container54() {
  return <div className="absolute bg-gray-300 h-[6px] left-[441.6px] opacity-60 top-0 w-px" data-name="Container" />;
}

function Container55() {
  return (
    <div className="absolute h-[12px] left-0 top-[28px] w-[451px]" data-name="Container">
      <Container6 />
      <Container7 />
      <Container8 />
      <Container9 />
      <Container10 />
      <Container11 />
      <Container12 />
      <Container13 />
      <Container14 />
      <Container15 />
      <Container16 />
      <Container17 />
      <Container18 />
      <Container19 />
      <Container20 />
      <Container21 />
      <Container22 />
      <Container23 />
      <Container24 />
      <Container25 />
      <Container26 />
      <Container27 />
      <Container28 />
      <Container29 />
      <Container30 />
      <Container31 />
      <Container32 />
      <Container33 />
      <Container34 />
      <Container35 />
      <Container36 />
      <Container37 />
      <Container38 />
      <Container39 />
      <Container40 />
      <Container41 />
      <Container42 />
      <Container43 />
      <Container44 />
      <Container45 />
      <Container46 />
      <Container47 />
      <Container48 />
      <Container49 />
      <Container50 />
      <Container51 />
      <Container52 />
      <Container53 />
      <Container54 />
    </div>
  );
}

function Container56() {
  return <div className="absolute bg-gray-200 h-[12px] left-0 rounded-[10px] top-[28px] w-[451px]" data-name="Container" />;
}

function Container57() {
  return <div className="absolute bg-blue-600 h-[12px] left-[151.01px] rounded-[8px] top-[28px] w-[36.227px]" data-name="Container" />;
}

function Container58() {
  return <div className="absolute bg-blue-600 h-[12px] left-[188.59px] rounded-[8px] top-[28px] w-[36.227px]" data-name="Container" />;
}

function Container59() {
  return <div className="absolute bg-blue-600 h-[12px] left-[226.17px] rounded-[8px] top-[28px] w-[36.227px]" data-name="Container" />;
}

function Container60() {
  return <div className="absolute bg-blue-600 h-[12px] left-[263.76px] rounded-[8px] top-[28px] w-[36.227px]" data-name="Container" />;
}

function Container61() {
  return <div className="absolute bg-blue-600 h-[12px] left-[301.34px] rounded-[8px] top-[28px] w-[36.227px]" data-name="Container" />;
}

function Group1() {
  return (
    <div className="absolute h-[23px] left-[151px] top-[45.5px] w-[28.2px]">
      <div className="absolute bottom-0 left-[-1.77%] right-[-0.89%] top-0">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29 23">
          <g id="Group 1">
            <path d="M0.500001 2.18557e-08L0.5 23" id="Vector 1" stroke="var(--stroke-0, #9CA3AF)" />
            <path d="M19.3 12L19.3 23" id="Vector 3" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
            <path d="M9.89999 12L9.89999 23" id="Vector 4" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
            <path d="M28.7 12L28.7 23" id="Vector 5" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute h-[23px] left-[226.2px] top-[45.5px] w-[28.2px]">
      <div className="absolute bottom-0 left-[-1.77%] right-[-0.89%] top-0">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29 23">
          <g id="Group 3">
            <path d="M0.500001 2.18557e-08L0.5 23" id="Vector 1" stroke="var(--stroke-0, #9CA3AF)" />
            <path d="M19.3 12L19.3 23" id="Vector 3" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
            <path d="M9.89999 12L9.89999 23" id="Vector 4" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
            <path d="M28.7 12L28.7 23" id="Vector 5" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute h-[23px] left-[188.6px] top-[45.5px] w-[28.2px]">
      <div className="absolute bottom-0 left-[-1.77%] right-[-0.89%] top-0">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29 23">
          <g id="Group 3">
            <path d="M0.500001 2.18557e-08L0.5 23" id="Vector 1" stroke="var(--stroke-0, #9CA3AF)" />
            <path d="M19.3 12L19.3 23" id="Vector 3" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
            <path d="M9.89999 12L9.89999 23" id="Vector 4" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
            <path d="M28.7 12L28.7 23" id="Vector 5" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group4() {
  return (
    <div className="absolute h-[23px] left-[263.8px] top-[45.5px] w-[28.2px]">
      <div className="absolute bottom-0 left-[-1.77%] right-[-0.89%] top-0">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29 23">
          <g id="Group 4">
            <path d="M0.500001 2.18557e-08L0.5 23" id="Vector 1" stroke="var(--stroke-0, #9CA3AF)" />
            <path d="M19.3 12L19.3 23" id="Vector 3" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
            <path d="M9.90002 12L9.90002 23" id="Vector 4" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
            <path d="M28.7 12L28.7 23" id="Vector 5" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group5() {
  return (
    <div className="absolute contents left-[151px] top-[45.5px]">
      <Group1 />
      <Group3 />
      <Group2 />
      <Group4 />
    </div>
  );
}

function Group10() {
  return (
    <div className="absolute h-[23px] left-px top-[45.5px] w-[28.2px]">
      <div className="absolute bottom-0 left-[-1.77%] right-[-0.89%] top-0">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29 23">
          <g id="Group 1">
            <path d="M0.500001 2.18557e-08L0.5 23" id="Vector 1" stroke="var(--stroke-0, #9CA3AF)" />
            <path d="M19.3 12L19.3 23" id="Vector 3" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
            <path d="M9.9 12L9.9 23" id="Vector 4" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
            <path d="M28.7 12L28.7 23" id="Vector 5" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group11() {
  return (
    <div className="absolute h-[23px] left-[76.2px] top-[45.5px] w-[28.2px]">
      <div className="absolute bottom-0 left-[-1.77%] right-[-0.89%] top-0">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29 23">
          <g id="Group 3">
            <path d="M0.500001 2.18557e-08L0.5 23" id="Vector 1" stroke="var(--stroke-0, #9CA3AF)" />
            <path d="M19.3 12L19.3 23" id="Vector 3" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
            <path d="M9.89999 12L9.89999 23" id="Vector 4" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
            <path d="M28.7 12L28.7 23" id="Vector 5" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group12() {
  return (
    <div className="absolute h-[23px] left-[38.6px] top-[45.5px] w-[28.2px]">
      <div className="absolute bottom-0 left-[-1.77%] right-[-0.89%] top-0">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29 23">
          <g id="Group 2">
            <path d="M0.500001 2.18557e-08L0.5 23" id="Vector 1" stroke="var(--stroke-0, #9CA3AF)" />
            <path d="M19.3 12L19.3 23" id="Vector 3" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
            <path d="M9.89999 12L9.89999 23" id="Vector 4" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
            <path d="M28.7 12L28.7 23" id="Vector 5" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group13() {
  return (
    <div className="absolute h-[23px] left-[113.8px] top-[45.5px] w-[28.2px]">
      <div className="absolute bottom-0 left-[-1.77%] right-[-0.89%] top-0">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29 23">
          <g id="Group 4">
            <path d="M0.500001 2.18557e-08L0.5 23" id="Vector 1" stroke="var(--stroke-0, #9CA3AF)" />
            <path d="M19.3 12L19.3 23" id="Vector 3" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
            <path d="M9.90001 12L9.90001 23" id="Vector 4" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
            <path d="M28.7 12L28.7 23" id="Vector 5" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group7() {
  return (
    <div className="absolute contents left-px top-[45.5px]">
      <Group10 />
      <Group11 />
      <Group12 />
      <Group13 />
    </div>
  );
}

function Group14() {
  return (
    <div className="absolute h-[23px] left-[300px] top-[45.5px] w-[28.2px]">
      <div className="absolute bottom-0 left-[-1.77%] right-[-0.89%] top-0">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29 23">
          <g id="Group 1">
            <path d="M0.500001 2.18557e-08L0.5 23" id="Vector 1" stroke="var(--stroke-0, #9CA3AF)" />
            <path d="M19.3 12L19.3 23" id="Vector 3" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
            <path d="M9.89999 12L9.89999 23" id="Vector 4" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
            <path d="M28.7 12L28.7 23" id="Vector 5" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group15() {
  return (
    <div className="absolute h-[23px] left-[375.2px] top-[45.5px] w-[28.2px]">
      <div className="absolute bottom-0 left-[-1.77%] right-[-0.89%] top-0">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29 23">
          <g id="Group 3">
            <path d="M0.500001 2.18557e-08L0.5 23" id="Vector 1" stroke="var(--stroke-0, #9CA3AF)" />
            <path d="M19.3 12L19.3 23" id="Vector 3" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
            <path d="M9.89999 12L9.89999 23" id="Vector 4" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
            <path d="M28.7 12L28.7 23" id="Vector 5" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group16() {
  return (
    <div className="absolute h-[23px] left-[337.6px] top-[45.5px] w-[28.2px]">
      <div className="absolute bottom-0 left-[-1.77%] right-[-0.89%] top-0">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29 23">
          <g id="Group 3">
            <path d="M0.500001 2.18557e-08L0.5 23" id="Vector 1" stroke="var(--stroke-0, #9CA3AF)" />
            <path d="M19.3 12L19.3 23" id="Vector 3" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
            <path d="M9.89999 12L9.89999 23" id="Vector 4" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
            <path d="M28.7 12L28.7 23" id="Vector 5" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group17() {
  return (
    <div className="absolute h-[23px] left-[412.8px] top-[45.5px] w-[38.2px]">
      <div className="absolute bottom-0 left-[-1.31%] right-[-1.31%] top-0">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 40 23">
          <g id="Group 4">
            <path d="M0.500001 2.18557e-08L0.5 23" id="Vector 1" stroke="var(--stroke-0, #9CA3AF)" />
            <path d="M38.7 2.18557e-08L38.7 23" id="Vector 6" stroke="var(--stroke-0, #9CA3AF)" />
            <path d="M19.3 12L19.3 23" id="Vector 3" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
            <path d="M9.90003 12L9.90003 23" id="Vector 4" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
            <path d="M28.7 12L28.7 23" id="Vector 5" stroke="var(--stroke-0, #9CA3AF)" strokeWidth="0.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group6() {
  return (
    <div className="absolute contents left-[300px] top-[45.5px]">
      <Group14 />
      <Group15 />
      <Group16 />
      <Group17 />
    </div>
  );
}

function Group8() {
  return (
    <div className="absolute contents left-px top-[45.5px]">
      <Group5 />
      <Group7 />
      <Group6 />
    </div>
  );
}

function Container62() {
  return (
    <div className="absolute h-[68px] left-0 top-0 w-[451px]" data-name="Container">
      <Container5 />
      <Container55 />
      <Container56 />
      <Container57 />
      <Container58 />
      <Container59 />
      <Container60 />
      <Container61 />
      <Group8 />
    </div>
  );
}

function Text() {
  return (
    <div className="h-[18px] relative shrink-0 w-[34.758px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[18px] relative w-[34.758px]">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-0 not-italic text-[12px] text-gray-500 text-nowrap top-px whitespace-pre">12 AM</p>
      </div>
    </div>
  );
}

function Text1() {
  return (
    <div className="h-[18px] relative shrink-0 w-[29.477px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[18px] relative w-[29.477px]">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-0 not-italic text-[12px] text-gray-500 text-nowrap top-px whitespace-pre">3 AM</p>
      </div>
    </div>
  );
}

function Text2() {
  return (
    <div className="h-[18px] relative shrink-0 w-[29.594px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[18px] relative w-[29.594px]">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-0 not-italic text-[12px] text-gray-500 text-nowrap top-px whitespace-pre">6 AM</p>
      </div>
    </div>
  );
}

function Text3() {
  return (
    <div className="h-[18px] relative shrink-0 w-[29.594px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[18px] relative w-[29.594px]">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-0 not-italic text-[12px] text-gray-500 text-nowrap top-px whitespace-pre">9 AM</p>
      </div>
    </div>
  );
}

function Text4() {
  return (
    <div className="h-[18px] relative shrink-0 w-[34.297px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[18px] relative w-[34.297px]">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-0 not-italic text-[12px] text-gray-500 text-nowrap top-px whitespace-pre">12 PM</p>
      </div>
    </div>
  );
}

function Text5() {
  return (
    <div className="h-[18px] relative shrink-0 w-[29.016px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[18px] relative w-[29.016px]">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-0 not-italic text-[12px] text-gray-500 text-nowrap top-px whitespace-pre">3 PM</p>
      </div>
    </div>
  );
}

function Text6() {
  return (
    <div className="h-[18px] relative shrink-0 w-[29.133px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[18px] relative w-[29.133px]">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-0 not-italic text-[12px] text-gray-500 text-nowrap top-px whitespace-pre">6 PM</p>
      </div>
    </div>
  );
}

function Text7() {
  return (
    <div className="h-[18px] relative shrink-0 w-[29.133px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid box-border h-[18px] relative w-[29.133px]">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[18px] left-0 not-italic text-[12px] text-gray-500 text-nowrap top-px whitespace-pre">9 PM</p>
      </div>
    </div>
  );
}

function Container63() {
  return (
    <div className="absolute box-border content-stretch flex h-[18px] items-start justify-between left-0 pl-0 pr-[0.055px] py-0 top-[71px] w-[451px]" data-name="Container">
      <Text />
      <Text1 />
      <Text2 />
      <Text3 />
      <Text4 />
      <Text5 />
      <Text6 />
      <Text7 />
      <Text />
    </div>
  );
}

export default function Group9() {
  return (
    <div className="relative size-full">
      <Container62 />
      <Container63 />
    </div>
  );
}