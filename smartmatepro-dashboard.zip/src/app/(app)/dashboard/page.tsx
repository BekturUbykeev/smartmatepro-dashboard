import dynamic from "next/dynamic";
const CalendarGrid = dynamic(() => import("@/components/CalendarGrid"), { ssr: false }); // <-- важное
import NewEventButton from "@/components/NewEventButton";

async function getWeek(offset = 0) {
    const base = process.env.NEXT_PUBLIC_BASE_URL ?? "";
    const res = await fetch(`${base}/api/calendar/week?offset=${offset}&mode=live`, { cache: "no-store" });
    if (!res.ok) throw new Error("Failed to load events");
    return res.json();
}

export default async function DashboardPage() {
    const data = await getWeek(0);
    const TZ = process.env.NEXT_PUBLIC_TZ || process.env.TIMEZONE || "America/Los_Angeles";

    return (
        <main className="p-6 space-y-6">
            <div className="flex items-center gap-3">
                <h1 className="text-2xl font-bold">SmartMate Pro — Schedule</h1>
                <NewEventButton />
            </div>

            {/* CalendarGrid рендерится только на клиенте — никаких расхождений SSR/CSR */}
            <CalendarGrid
                weekStartISO={data.start}
                events={data.events}
                timezone={TZ}
                hours={{ start: 10, end: 18 }}
            />
        </main>
    );
}
