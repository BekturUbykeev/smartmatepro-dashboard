// components/CalendarGrid.tsx
"use client";
import { useMemo } from "react";

type EventItem = { id: string; title: string; start: string; end: string };
type Props = {
    weekStartISO: string;
    events: EventItem[];
    timezone?: string; // e.g. "UTC" или "America/Los_Angeles"
    hours?: { start: number; end: number };
};

function isoToDate(iso: string) { return new Date(iso); }
function floorToHour(d: Date) { const nd = new Date(d); nd.setMinutes(0, 0, 0); return nd; }
function addDays(d: Date, days: number) { const nd = new Date(d); nd.setDate(nd.getDate() + days); return nd; }
function setHour(d: Date, hour: number) { const nd = new Date(d); nd.setHours(hour, 0, 0, 0); return nd; }
function minutesBetween(a: Date, b: Date) { return Math.max(0, Math.round((b.getTime() - a.getTime()) / 60000)); }

export default function CalendarGrid({
    weekStartISO,
    events,
    timezone = "UTC",
    hours = { start: 10, end: 18 },
}: Props) {
    const fmtDay = useMemo(() =>
        new Intl.DateTimeFormat("en-US", {
            weekday: "short",
            month: "short",
            day: "numeric",
            timeZone: timezone,
        }), [timezone]);

    const fmtTime = useMemo(() =>
        new Intl.DateTimeFormat("en-US", {
            hour: "2-digit",
            minute: "2-digit",
            hour12: true,
            timeZone: timezone,
        }), [timezone]);

    const days = useMemo(() => {
        const start = isoToDate(weekStartISO);
        return Array.from({ length: 7 }, (_, i) => addDays(start, i));
    }, [weekStartISO]);

    const hourMarks = useMemo(() => {
        const list: number[] = [];
        for (let h = hours.start; h <= hours.end; h++) list.push(h);
        return list;
    }, [hours]);

    const positioned = useMemo(() => {
        const startOfGrid = setHour(isoToDate(weekStartISO), hours.start);
        const endOfGrid = setHour(addDays(isoToDate(weekStartISO), 7), hours.end);

        return events
            .filter((e) => {
                const s = isoToDate(e.start);
                const en = isoToDate(e.end);
                return en > startOfGrid && s < endOfGrid;
            })
            .map((e) => {
                const s = isoToDate(e.start);
                const dayIdx = Math.floor(
                    (floorToHour(s).getTime() - floorToHour(isoToDate(weekStartISO)).getTime()) /
                    (24 * 60 * 60 * 1000)
                );

                const dayStart = setHour(addDays(isoToDate(weekStartISO), dayIdx), hours.start);
                const dayEnd = setHour(addDays(isoToDate(weekStartISO), dayIdx), hours.end);
                const daySpanMin = minutesBetween(dayStart, dayEnd);

                const topMin = Math.max(0, minutesBetween(dayStart, s));
                const durMin = Math.max(30, minutesBetween(s, isoToDate(e.end)));

                return {
                    ...e,
                    dayIdx,
                    topPct: Math.min(100, (topMin / daySpanMin) * 100),
                    heightPct: Math.min(100, (durMin / daySpanMin) * 100),
                };
            })
            .filter((e) => e.dayIdx >= 0 && e.dayIdx <= 6);
    }, [events, hours, weekStartISO]);

    return (
        <div className="w-full overflow-hidden rounded-2xl border border-gray-200 shadow-sm">
            <div className="grid grid-cols-8 border-b bg-white/60 backdrop-blur">
                <div className="p-3 text-sm font-medium text-gray-500">Time</div>
                {days.map((d, i) => (
                    <div key={i} className="p-3 text-sm font-semibold">
                        {fmtDay.format(d)} {/* фиксированная timeZone */}
                    </div>
                ))}
            </div>

            <div className="grid grid-cols-8">
                <div className="border-r bg-gray-50">
                    {hourMarks.map((h) => (
                        <div key={h} className="h-16 border-b px-2 text-xs text-gray-500 flex items-start">
                            {h}:00
                        </div>
                    ))}
                </div>

                {days.map((_, dayIdx) => (
                    <div key={dayIdx} className="relative border-r last:border-r-0">
                        {hourMarks.map((h) => (
                            <div key={h} className="h-16 border-b" />
                        ))}

                        {positioned
                            .filter((e) => e.dayIdx === dayIdx)
                            .map((e) => (
                                <div
                                    key={e.id}
                                    className="absolute left-1 right-1 rounded-md border bg-white shadow-sm p-2 text-xs"
                                    style={{ top: `${e.topPct}%`, height: `${e.heightPct}%` }}
                                    title={e.title}
                                >
                                    <div className="font-semibold truncate">{e.title || "Booking"}</div>
                                    <div className="opacity-70">
                                        {fmtTime.format(new Date(e.start))} – {fmtTime.format(new Date(e.end))}
                                    </div>
                                </div>
                            ))}
                    </div>
                ))}
            </div>
        </div>
    );
}
