
  # AI Assistant Prototype

  This is a code bundle for AI Assistant Prototype. The original project is available at https://www.figma.com/design/8azP3lyn8EAN8PtNFZtJPw/AI-Assistant-Prototype.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  