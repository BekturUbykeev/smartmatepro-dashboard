"use client";

import { useState } from "react";
import { DateTime } from "luxon";

// ВАРИАНТ 1 (если есть alias "@/*")
import { useEvents } from "@/hooks/useEvents";
import { useAvailability } from "@/hooks/useAvailability";

// // ВАРИАНТ 2 (если alias НЕТ — раскомментируй и поправь путь)
// import { useEvents } from "../../hooks/useEvents";
// import { useAvailability } from "../../hooks/useAvailability";

const TZ = "America/Los_Angeles";

export default function EventForm({
    initialClientId,
    initialDateISO,
    onDone,
}: {
    initialClientId?: string | null;
    initialDateISO?: string | null; // YYYY-MM-DD
    onDone?: () => void;
}) {
    const [clientId, setClientId] = useState(initialClientId ?? "");
    const [dateISO, setDateISO] = useState(
        initialDateISO ?? DateTime.now().setZone(TZ).toISODate()
    );

    // Безопасно получаем события за день (ISO только, никаких Date.now() на сервере)
    const fromISO = DateTime.fromISO(dateISO, { zone: TZ }).startOf("day").toISO();
    const toISO = DateTime.fromISO(dateISO, { zone: TZ }).endOf("day").toISO();

    const { list, create } = useEvents({ fromISO, toISO });

    const eventsForDay = list.data ?? [];
    const slots = useAvailability(dateISO, eventsForDay);

    // Если слотов нет (например, всё занято) — не падаем
    const [slotIndex, setSlotIndex] = useState<number>(0);
    const [title, setTitle] = useState("Appointment");

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        const slot = slots[slotIndex];
        if (!slot || !clientId) return;

        await create.mutateAsync({
            clientId,
            title,
            start: slot.start.toISO(),
            end: slot.end.toISO(),
            notes: "",
        });

        onDone?.();
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-3">
            {/* ClientPicker – позже заменим на реальный */}
            <div className="space-y-1">
                <label className="text-sm font-medium">Client ID</label>
                <input
                    className="w-full rounded-lg border px-3 py-2"
                    value={clientId}
                    onChange={(e) => setClientId(e.target.value)}
                    placeholder="client_123"
                    required
                />
            </div>

            {/* Дата — client-only, ISO строка */}
            <div className="space-y-1">
                <label className="text-sm font-medium">Date</label>
                <input
                    type="date"
                    className="w-full rounded-lg border px-3 py-2"
                    value={dateISO ?? ""}
                    onChange={(e) => setDateISO(e.target.value)}
                />
            </div>

            {/* SlotPicker — слоты 10–12, 12–14, 14–16, 16–18 */}
            <div className="space-y-1">
                <label className="text-sm font-medium">Time</label>
                <select
                    className="w-full rounded-lg border px-3 py-2"
                    value={slotIndex}
                    onChange={(e) => setSlotIndex(Number(e.target.value))}
                    disabled={slots.length === 0}
                >
                    {slots.length === 0 ? (
                        <option>Нет доступных слотов</option>
                    ) : (
                        slots.map((s, i) => (
                            <option key={i} value={i}>
                                {s.start.setZone(TZ).toFormat("HH:mm")} — {s.end.setZone(TZ).toFormat("HH:mm")}
                            </option>
                        ))
                    )}
                </select>
                {slots.length === 0 && (
                    <p className="text-xs text-red-500">Все слоты заняты на этот день.</p>
                )}
            </div>

            <div className="space-y-1">
                <label className="text-sm font-medium">Title</label>
                <input
                    className="w-full rounded-lg border px-3 py-2"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                />
            </div>

            <div className="flex justify-end gap-2">
                <button
                    type="submit"
                    className="rounded-xl bg-black px-4 py-2 text-white"
                    disabled={create.isPending || slots.length === 0}
                >
                    {create.isPending ? "Saving..." : "Save"}
                </button>
            </div>
        </form>
    );
}
