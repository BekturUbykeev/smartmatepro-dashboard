// src/app/api/calendar/week/route.ts
import { NextResponse } from "next/server";
import { DateTime } from "luxon";
import { getAuth, getCalendar } from "@/lib/gcal";

export const runtime = "nodejs";          // не edge
export const dynamic = "force-dynamic";   // без кэша

type EventDTO = {
    id: string;
    title: string;
    start: string; // ISO
    end: string;   // ISO
};

export async function GET(req: Request) {
    try {
        const { searchParams } = new URL(req.url);
        const offset = Number(searchParams.get("offset") ?? 0);
        const mode = (searchParams.get("mode") ??
            process.env.CALENDAR_MODE ??
            "live") as "live" | "memory";

        const TZ = process.env.TIMEZONE || "UTC";

        // Неделя: с ВОСКРЕСЕНЬЯ 00:00 по локальной TZ
        const base = DateTime.now().setZone(TZ).plus({ weeks: offset });
        const monday = base.startOf("week");         // ISO week (понедельник)
        const sunday = monday.minus({ days: 1 });    // воскресенье
        const weekStart = sunday.startOf("day");
        const weekEnd = weekStart.plus({ days: 7 });

        if (mode === "memory") {
            return NextResponse.json({
                events: [],
                start: weekStart.toISO(),
                end: weekEnd.toISO(),
                mode: "memory",
            });
        }

        // LIVE: читаем из Google Calendar
        const auth = getAuth(["https://www.googleapis.com/auth/calendar.readonly"]);
        const calendar = getCalendar(auth);
        const calendarId = process.env.GOOGLE_CALENDAR_ID || "primary";

        const { data } = await calendar.events.list({
            calendarId,
            timeMin: weekStart.toISO(),
            timeMax: weekEnd.toISO(),
            singleEvents: true,
            orderBy: "startTime",
        });

        const events: EventDTO[] =
            (data.items ?? []).map((e) => ({
                id: e.id!,
                title: e.summary ?? "Booking",
                start: e.start?.dateTime ?? e.start?.date!,
                end: e.end?.dateTime ?? e.end?.date!,
            })) ?? [];

        return NextResponse.json({
            events,
            start: weekStart.toISO(),
            end: weekEnd.toISO(),
            mode: "live",
        });
    } catch (err: any) {
        return NextResponse.json(
            { ok: false, error: err?.message ?? "Unknown error" },
            { status: 500 }
        );
    }
}
