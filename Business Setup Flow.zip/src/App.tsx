import { useState } from 'react'
import { Sidebar } from './components/Sidebar'
import { BusinessSetup } from './components/BusinessSetup'
import { Dashboard } from './components/Dashboard'
import { Chats } from './components/Chats'
import { Calendar } from './components/Calendar'
import { Integrations } from './components/Integrations'
import { Pricing } from './components/Pricing'
import { Users } from './components/Users'
import { Support } from './components/Support'
import { Settings } from './components/Settings'

export default function App() {
  const [activeSection, setActiveSection] = useState('business-setup')

  const renderContent = () => {
    switch (activeSection) {
      case 'dashboard':
        return <Dashboard />
      case 'business-setup':
        return <BusinessSetup />
      case 'chats':
        return <Chats />
      case 'calendar':
        return <Calendar />
      case 'integrations':
        return <Integrations />
      case 'pricing':
        return <Pricing />
      case 'users':
        return <Users />
      case 'support':
        return <Support />
      case 'settings':
        return <Settings />
      default:
        return <BusinessSetup />
    }
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar 
        activeSection={activeSection} 
        onSectionChange={setActiveSection} 
      />
      <main className="flex-1 overflow-auto">
        {renderContent()}
      </main>
    </div>
  )
}