"use client";

// Собираем ISO с локальным смещением (не Z)
function buildLocalISO(d: Date) {
    const pad = (n: number) => String(n).padStart(2, "0");
    const y = d.getFullYear();
    const m = pad(d.getMonth() + 1);
    const day = pad(d.getDate());
    const hh = pad(d.getHours());
    const mm = pad(d.getMinutes());
    const off = -d.getTimezoneOffset(); // в минутах
    const sign = off >= 0 ? "+" : "-";
    const oh = pad(Math.floor(Math.abs(off) / 60));
    const om = pad(Math.abs(off) % 60);
    return `${y}-${m}-${day}T${hh}:${mm}:00${sign}${oh}:${om}`;
}

export default function NewEventButton() {
    async function onClick() {
        const dateStr = window.prompt("Date (YYYY-MM-DD)?");
        if (!dateStr) return;
        if (!/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
            alert("Введите дату строго в формате YYYY-MM-DD (например, 2025-08-31).");
            return;
        }

        // Приоритет: 14 → 12 → 16 → 10 (локальное время устройства)
        for (const h of [14, 12, 16, 10]) {
            const start = new Date(`${dateStr}T00:00:00`);
            start.setHours(h, 0, 0, 0);
            const end = new Date(start);
            end.setHours(h + 2, 0, 0, 0);

            const res = await fetch("/api/calendar/create", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    title: "Booking",
                    start: buildLocalISO(start),
                    end: buildLocalISO(end),
                    client: { name: "Walk-in", phone: "" },
                }),
            });

            const data = await res.json().catch(() => ({}));
            if (res.ok && data?.ok) {
                location.reload(); // позже заменим на SWR-рефетч
                return;
            }
            if (data?.error && data.error !== "Slot overlaps") {
                alert("Error: " + data.error);
                return;
            }
        }
        alert("Нет свободных слотов (14 → 12 → 16 → 10).");
    }

    return (
        <button
            onClick={onClick}
            className="rounded-xl border px-3 py-2 text-sm shadow-sm hover:bg-gray-50"
        >
            + New Event
        </button>
    );
}
