export default function BaseCalendarEvent() {
  return (
    <div className="bg-[#34ca57] relative size-full" data-name="_base-calendar-event">
      <div className="size-full">
        <div className="size-full" />
      </div>
    </div>
  );
}