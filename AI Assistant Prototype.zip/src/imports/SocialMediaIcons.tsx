export default function SocialMediaIcons() {
  return <div className="bg-white size-full" data-name="Social Media Icons" />;
}