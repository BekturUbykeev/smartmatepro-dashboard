"use client";

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

export type EventItem = {
    id: string;
    clientId: string;
    title: string;
    start: string; // ISO
    end: string;   // ISO
    notes?: string;
};

async function fetchEvents(params?: { fromISO?: string; toISO?: string }) {
    const query = new URLSearchParams();
    if (params?.fromISO) query.set("from", params.fromISO);
    if (params?.toISO) query.set("to", params.toISO);
    const res = await fetch(`/api/calendar?${query.toString()}`, { cache: "no-store" });
    if (!res.ok) throw new Error("Failed to load events");
    return (await res.json()) as EventItem[];
}

export function useEvents(params?: { fromISO?: string; toISO?: string }) {
    const qc = useQueryClient();

    const list = useQuery({
        queryKey: ["events", params?.fromISO, params?.toISO],
        queryFn: () => fetchEvents(params),
        staleTime: 15_000,
    });

    const create = useMutation({
        mutationFn: async (payload: Omit<EventItem, "id">) => {
            const res = await fetch(`/api/calendar`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload),
            });
            if (!res.ok) throw new Error("Failed to create");
            return (await res.json()) as EventItem;
        },
        onSuccess: () => qc.invalidateQueries({ queryKey: ["events"] }),
    });

    const update = useMutation({
        mutationFn: async (payload: Partial<EventItem> & { id: string }) => {
            const res = await fetch(`/api/calendar/${payload.id}`, {
                method: "PATCH",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload),
            });
            if (!res.ok) throw new Error("Failed to update");
            return (await res.json()) as EventItem;
        },
        onSuccess: () => qc.invalidateQueries({ queryKey: ["events"] }),
    });

    const remove = useMutation({
        mutationFn: async (id: string) => {
            const res = await fetch(`/api/calendar/${id}`, { method: "DELETE" });
            if (!res.ok) throw new Error("Failed to delete");
            return true;
        },
        onSuccess: () => qc.invalidateQueries({ queryKey: ["events"] }),
    });

    return { list, create, update, remove };
}
