
  # Business Setup Flow

  This is a code bundle for Business Setup Flow. The original project is available at https://www.figma.com/design/JEwbRvMKNMAjMwXs6vcX4s/Business-Setup-Flow.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  