import { cn } from './ui/utils'
import { 
  Wrench, 
  MessageSquare, 
  Calendar, 
  BarChart3,
  Settings,
  Puzzle,
  Users,
  DollarSign,
  HeadphonesIcon
} from 'lucide-react'

interface SidebarProps {
  activeSection: string
  onSectionChange: (section: string) => void
}

export function Sidebar({ activeSection, onSectionChange }: SidebarProps) {
  const menuItems = [
    { id: 'business-setup', label: 'Business Setup', icon: Wrench },
    { id: 'chats', label: 'Chats', icon: MessageSquare },
    { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
    { id: 'calendar', label: 'Calendar', icon: Calendar },
    { id: 'integrations', label: 'Integrations', icon: Puzzle },
    { id: 'pricing', label: 'Pricing', icon: DollarSign },
    { id: 'users', label: 'Users', icon: Users },
    { id: 'support', label: 'Support', icon: HeadphonesIcon },
    { id: 'settings', label: 'Settings', icon: Settings },
  ]

  return (
    <aside className="w-64 bg-slate-900 text-white flex flex-col">
      {/* Logo */}
      <div className="p-6">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold">S</span>
          </div>
          <div>
            <h1 className="font-semibold">Smart</h1>
            <p className="text-xs text-slate-400">Mate PRO</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-4">
        <ul className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon
            const isActive = activeSection === item.id
            
            return (
              <li key={item.id}>
                <button
                  onClick={() => onSectionChange(item.id)}
                  className={cn(
                    "w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg transition-colors",
                    isActive 
                      ? "bg-blue-600 text-white" 
                      : "text-slate-300 hover:bg-slate-800 hover:text-white"
                  )}
                >
                  <Icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </button>
              </li>
            )
          })}
        </ul>
      </nav>

      {/* Premium upgrade */}
      <div className="p-4">
        <div className="bg-blue-600 rounded-lg p-4">
          <div className="flex items-center space-x-2 mb-2">
            <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center">
              <span className="text-blue-600 font-bold text-sm">S</span>
            </div>
            <span className="font-semibold text-sm">Premium</span>
          </div>
          <p className="text-xs text-blue-100 mb-3">Get access to all features</p>
          <button className="w-full bg-white text-blue-600 text-sm font-medium py-2 px-3 rounded-md hover:bg-blue-50 transition-colors">
            Get Pro
          </button>
        </div>
      </div>
    </aside>
  )
}