import { useState } from 'react';
import { ChevronLeft, ChevronRight, Search, Plus, X, Clock, User } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

interface CalendarEvent {
  id: number;
  time: string;
  duration: number;
  title: string;
  color: string;
  day: number;
}

const events: CalendarEvent[] = [
  { id: 1, time: '9:00', duration: 2, title: "Men's Haircut", color: 'bg-[#0066FF]', day: 0 },
  { id: 2, time: '10:00', duration: 1, title: 'Styling', color: 'bg-[#10B981]', day: 3 },
  { id: 3, time: '13:00', duration: 1, title: 'Beard Trim', color: 'bg-[#F59E0B]', day: 0 },
  { id: 4, time: '13:00', duration: 1, title: 'Consultation', color: 'bg-[#8B5CF6]', day: 1 },
  { id: 5, time: '12:00', duration: 1.5, title: 'Full Service', color: 'bg-[#0066FF]', day: 5 },
  { id: 6, time: '17:00', duration: 1.5, title: 'Treatment', color: 'bg-[#10B981]', day: 5 },
];

const timeSlots = [
  '7:00', '8:00', '9:00', '10:00', '11:00', '12:00', 
  '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00'
];

const days = [
  { date: 25, day: 'Mon' },
  { date: 26, day: 'Tue' },
  { date: 27, day: 'Wed' },
  { date: 28, day: 'Thu' },
  { date: 29, day: 'Fri' },
  { date: 30, day: 'Sat' },
  { date: 1, day: 'Sun' },
];

type ViewType = 'Week' | 'Month' | 'Day' | 'List';

export function CalendarPage() {
  const [currentView, setCurrentView] = useState<ViewType>('Week');
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState<{ day: string; time: string } | null>(null);

  const getEventPosition = (time: string) => {
    const hour = parseInt(time.split(':')[0]);
    return (hour - 7) * 60;
  };

  const handleSlotClick = (day: string, time: string) => {
    setSelectedSlot({ day, time });
    setShowSettingsModal(true);
  };

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="px-8 py-6 border-b border-gray-200 max-w-4xl mx-auto w-full">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl text-black">Calendar</h1>
          <div className="flex items-center gap-2 w-80">
            <Search className="w-4 h-4 text-gray-400 absolute ml-3" />
            <Input 
              placeholder="Search" 
              className="pl-10 bg-gray-50 border border-gray-200 rounded-lg"
            />
          </div>
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button className="p-2 hover:bg-gray-50 rounded-lg transition-all">
              <ChevronLeft className="w-5 h-5 text-gray-700" />
            </button>
            <span className="text-base min-w-[140px] text-center text-black">September 2025</span>
            <button className="p-2 hover:bg-gray-50 rounded-lg transition-all">
              <ChevronRight className="w-5 h-5 text-gray-700" />
            </button>
          </div>

          <div className="flex items-center gap-2 bg-gray-50 rounded-lg p-1 border border-gray-200">
            {(['Week', 'Month', 'Day', 'List'] as ViewType[]).map((view) => (
              <button
                key={view}
                onClick={() => setCurrentView(view)}
                className={`px-4 py-2 rounded-lg text-sm transition-all duration-200 border ${
                  currentView === view
                    ? 'bg-white text-black border-gray-200'
                    : 'text-gray-500 hover:text-gray-900 border-transparent'
                }`}
              >
                {view}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Calendar Grid */}
      <div className="flex-1 overflow-auto">
        <div className="min-w-[900px]">
          {/* Days Header */}
          <div className="grid grid-cols-[60px_repeat(7,1fr)] border-b border-gray-100 sticky top-0 bg-white z-10">
            <div className="p-4 text-xs text-gray-400"></div>
            {days.map((day, index) => (
              <div key={index} className="p-4 text-center border-l border-gray-200">
                <div className="text-xl mb-1 text-black">{day.date}</div>
                <div className="text-xs text-gray-400">{day.day}</div>
              </div>
            ))}
          </div>

          {/* Time Grid */}
          <div className="relative">
            {timeSlots.map((time) => (
              <div
                key={time}
                className="grid grid-cols-[60px_repeat(7,1fr)] border-b border-gray-100"
                style={{ height: '60px' }}
              >
                <div className="p-2 text-xs text-gray-400 text-right pr-4">{time}</div>
                {days.map((day, dayIndex) => (
                  <div
                    key={dayIndex}
                    onClick={() => handleSlotClick(day.day, time)}
                    className="border-l border-gray-100 relative hover:bg-gray-50/50 transition-colors cursor-pointer"
                  />
                ))}
              </div>
            ))}

            {/* Events Layer */}
            <div className="absolute top-0 left-0 right-0 bottom-0 pointer-events-none">
              <div className="grid grid-cols-[60px_repeat(7,1fr)] h-full">
                <div></div>
                {days.map((_, dayIndex) => (
                  <div key={dayIndex} className="relative">
                    {events
                      .filter((event) => event.day === dayIndex)
                      .map((event) => (
                        <div
                          key={event.id}
                          className={`absolute left-1 right-1 ${event.color} text-white rounded-lg p-2 pointer-events-auto cursor-pointer hover:opacity-90 transition-all`}
                          style={{
                            top: `${getEventPosition(event.time)}px`,
                            height: `${event.duration * 60 - 4}px`,
                          }}
                        >
                          <div className="text-xs opacity-90">{event.time}</div>
                          <div className="text-sm mt-0.5">{event.title}</div>
                        </div>
                      ))}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Settings Modal */}
      <Dialog open={showSettingsModal} onOpenChange={setShowSettingsModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-black">New Event</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <label className="text-sm text-gray-500 mb-2 block">Title</label>
              <Input placeholder="Event title" className="rounded-lg border-gray-200" />
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-sm text-gray-500 mb-2 block">Date</label>
                <Input 
                  value={selectedSlot?.day || ''} 
                  readOnly 
                  className="rounded-lg bg-gray-50 border-gray-200" 
                />
              </div>
              <div>
                <label className="text-sm text-gray-500 mb-2 block">Time</label>
                <Input 
                  value={selectedSlot?.time || ''} 
                  readOnly 
                  className="rounded-lg bg-gray-50 border-gray-200" 
                />
              </div>
            </div>

            <div>
              <label className="text-sm text-gray-500 mb-2 block">Duration</label>
              <Select defaultValue="60">
                <SelectTrigger className="rounded-lg border-gray-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="30">30 minutes</SelectItem>
                  <SelectItem value="60">1 hour</SelectItem>
                  <SelectItem value="90">1.5 hours</SelectItem>
                  <SelectItem value="120">2 hours</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm text-gray-500 mb-2 block">Service Type</label>
              <Select defaultValue="haircut">
                <SelectTrigger className="rounded-lg border-gray-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="haircut">Men's Haircut</SelectItem>
                  <SelectItem value="beard">Beard Trim</SelectItem>
                  <SelectItem value="styling">Styling</SelectItem>
                  <SelectItem value="full">Full Service</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm text-gray-500 mb-2 block">Client</label>
              <Input placeholder="Client name (optional)" className="rounded-lg border-gray-200" />
            </div>

            <div>
              <label className="text-sm text-gray-500 mb-2 block">Color</label>
              <div className="flex gap-2">
                {['bg-[#0066FF]', 'bg-[#8B5CF6]', 'bg-[#10B981]', 'bg-[#F59E0B]'].map((color, idx) => (
                  <button
                    key={idx}
                    className={`w-8 h-8 ${color} rounded-lg hover:scale-110 transition-all`}
                  />
                ))}
              </div>
            </div>
          </div>

          <div className="flex gap-2">
            <Button
              variant="outline"
              className="flex-1 rounded-lg border-gray-200"
              onClick={() => setShowSettingsModal(false)}
            >
              Cancel
            </Button>
            <Button
              className="flex-1 bg-[#0066FF] hover:bg-[#0052CC] text-white rounded-lg"
              onClick={() => setShowSettingsModal(false)}
            >
              Create Event
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* FAB */}
      <button 
        onClick={() => setShowSettingsModal(true)}
        className="fixed bottom-8 right-8 w-14 h-14 bg-[#0066FF] text-white rounded-full flex items-center justify-center hover:scale-105 transition-all duration-200"
      >
        <Plus className="w-6 h-6" />
      </button>
    </div>
  );
}
